﻿namespace Utils
{
    public static class AppSettings
    {
        // Valeur par défaut : "JSON" ou "XML"
        public static string LogFormat { get; set; } = "JSON";
    }
}